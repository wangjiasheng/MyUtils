package com.mediacodec1220.mp4.ffmpegwjs;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import java.io.File;

public class MainActivity extends AppCompatActivity {
    static
    {
        System.loadLibrary("avutil-55");
        System.loadLibrary("swresample-2");
        System.loadLibrary("avcodec-57");
        System.loadLibrary("avformat-57");
        System.loadLibrary("swscale-4");
        System.loadLibrary("avfilter-6");
        System.loadLibrary("avdevice-57");
        System.loadLibrary("main");
    }
    public native int FFmpegCommand(int argc,String[] argv);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final TextView mtext= (TextView) findViewById(R.id.mtext);
        mtext.setText("开始转码");

     //   String pathO= Environment.getExternalStorageDirectory().getAbsolutePath();
        final String inputPath = Environment.getExternalStorageDirectory().getAbsolutePath()+"/ddmsrec.mp4";
        final String outPath = Environment.getExternalStorageDirectory().getAbsolutePath()+"/1.mp4";

        final String t3gp="ffmpeg -i "+inputPath+" -vcodec h264 -s 480*640 -an -f mp4 "+outPath;//编码mpeg4封装格式  m4v   成功

        final   String cmd2="ffmpeg -i "+inputPath+" -vcodec copy -an "+outPath;//视频分离成功
        final   String cmd3="ffmpeg -i "+inputPath+" -vcodec copy -vn "+outPath;//
        final String com6="ffmpeg -i "+Environment.getExternalStorageDirectory().getAbsolutePath()+"/DCIM/Camera/4012.mp3"+" -acodec wmav2 -ab 64k -ar 44100 "+Environment.getExternalStorageDirectory().getAbsolutePath()+"/DCIM/Camera/4013.wav";//音频转码 wmav2


        final String com7="ffmpeg -codecs";//-vcodec   pc
        final String com8="ffmpeg -formats";//-f   pc
        final String com9="ffmpeg -filters";//vf args   pc


        new Thread(){
            @Override
            public void run() {
             //   super.run(
                        if(new File(inputPath).exists())
                        {
                            new File(outPath).delete();
                                String[] argv=t3gp.split(" ");
                                Integer argc=argv.length;
                                int iii=FFmpegCommand(argc,argv);
                                Log.e("LXS_Test","java_"+iii);
                                if(iii==-11000)
                                {
                                    mtext.setText("修复文件已经存在");


                                }
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    mtext.setText("sucess");
                                }
                            });
                        }
                        else
                        {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    mtext.setText("文件不存在"+inputPath);
                                }
                            });
                        }

                 }
        }.start();
    }
}
