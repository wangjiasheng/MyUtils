package com.wenyan.totravelcitywest;

/**
 * Created by 家胜 on 2016/6/6.
 */
public class ShareBean
{
    private int drableId;
    private String textName;

    public int getDrableId() {
        return drableId;
    }
    public void setDrableId(int drableId) {
        this.drableId = drableId;
    }

    public String getTextName() {
        return textName;
    }

    public void setTextName(String textName) {
        this.textName = textName;
    }
}
