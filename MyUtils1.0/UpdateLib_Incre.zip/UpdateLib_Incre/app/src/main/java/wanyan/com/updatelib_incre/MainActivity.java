package wanyan.com.updatelib_incre;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.wjs.updatelib.MD5Utils;
import com.wjs.updatelib.UpdateDialog;
import com.wjs.updatelib.Util;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final String updateURL=new URLBuilder(this).builderHost("http://192.168.1.95:8080/AppUpdate/CheckUpdate").incremental_update(true).build();
        TextView tv= (TextView) findViewById(R.id.textView);
        tv.setText(getPackageCodePath());
        tv.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                new NetworkTask(MainActivity.this,updateURL).execute();
            }
        });
    }
}
