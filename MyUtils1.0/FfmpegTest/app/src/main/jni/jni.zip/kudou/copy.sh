cp /home/xdpan/workspace/ff_study/src/play.c  ./
ndk-build -j2
